import sys
sys.path.append('..')

import RumiCar

if __name__ == "__main__":
    RumiCar.read_one_sensor()
