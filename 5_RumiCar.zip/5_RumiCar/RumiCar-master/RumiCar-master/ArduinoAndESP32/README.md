# Arduino Nano, ESP32版CM

Arduino NanoおよびESP32のCMに対応したRumiCarのExercise集です．

Exercise, Exercise-1.1~3.2については，Arduino IDEのライブラリ設定が必要です．[導入方法](./Libraries/README.md)を参照してください．    
上級編のExerciseにもライブラリ対応を計画中です．

