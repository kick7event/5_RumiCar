# rumicar-duck
It moving like a spot-billed duck

This is an introduction video in Japanese of my works via YouTube: 
https://youtu.be/PiFob1WZMyQ


 By Osamu "SAM" Onodera
 Twitter: @SAMonodera